# Study A EVAL tables (PROVISIONAL)

`xm-eval-analysis/5`, spec `eval_subset`, primary kappa 0.25, primary PMRT arm pmrt_nl_eq; commits 5a9518680. Protocol: docs/xmethod/PROTOCOL_A.md.

## V0 like-for-like (headline, R-42): recall / truth-null rate / placebo rate per cell

Every p arm scored at raw p <= .05 per edge (raw_p) and with the conformal placebo tau (tau), next to the score-only arms (tau; cdl also at the conference's fixed threshold, fixed). Rates are declaration rates; * INVALID, ~ INCONCLUSIVE; a tau row's placebo is its tuning column (reported, not in its validity). NA = not applicable (PMRT in R4: no known design, never recall 0); inv INVALID, inf infeasible (EVAL or T3), mis missing, unt untuned, few < 10 seeds; nig not in the arm's grid (pre-registered grid choice, R-54 / R-58).

### E1 R1

| arm | rule | n 500 |
|---|---|---|
| pmrt_nl_eq | raw_p | 1.00 / .035 / .042~ |
| pmrt_nl_eq | tau | 1.00 / .014 / .021 |
| pc_native | tau | 1.00 / .097* / .104~ |
| pcorr_eq | raw_p | 1.00 / .028 / .021 |
| pcorr_eq | tau | 1.00 / .007 / .000 |
| pcorr_native | raw_p | 1.00 / .042~ / .000 |
| pcorr_native | tau | 1.00 / .035 / .000 |

### E1 R2

| arm | rule | n 500 |
|---|---|---|
| pmrt_nl_eq | raw_p | 1.00 / .042 / .042~ |
| pmrt_nl_eq | tau | 1.00 / .028 / .021 |
| pc_native | tau | 1.00 / .090~ / .042~ |
| pcorr_eq | raw_p | 1.00 / .049~ / .042~ |
| pcorr_eq | tau | 1.00 / .049~ / .062~ |
| pcorr_native | raw_p | 1.00 / .188* / .062~ |
| pcorr_native | tau | 1.00 / .118* / .000 |

### E4 R1 l1

| arm | rule | n 500 |
|---|---|---|
| pmrt_nl_eq | raw_p | .25 / - / .000 |
| pmrt_nl_eq | tau | .08 / - / .000 |
| pc_native | tau | .50 / - / .000 |
| pcorr_eq | raw_p | .75 / - / .000 |
| pcorr_eq | tau | .25 / - / .000 |
| pcorr_native | raw_p | .75 / - / .000 |
| pcorr_native | tau | .42 / - / .000 |

### E4 R2 l1

| arm | rule | n 500 |
|---|---|---|
| pmrt_nl_eq | raw_p | .00 / - / .000 |
| pmrt_nl_eq | tau | .00 / - / .000 |
| pc_native | tau | .33 / - / .417* |
| pcorr_eq | raw_p | .08 / - / .083~ |
| pcorr_eq | tau | .00 / - / .083~ |
| pcorr_native | raw_p | .17 / - / .250~ |
| pcorr_native | tau | .25 / - / .250~ |

### E4 R3 l1

| arm | rule | n 500 |
|---|---|---|
| pmrt_nl_eq | raw_p | 1.00 / - / .083~ |
| pmrt_nl_eq | tau | 1.00 / - / .083~ |
| pc_native | tau | 1.00 / - / .083~ |
| pcorr_eq | raw_p | 1.00 / - / .000 |
| pcorr_eq | tau | 1.00 / - / .167~ |
| pcorr_native | raw_p | 1.00 / - / .000 |
| pcorr_native | tau | 1.00 / - / .167~ |

## V4 claim verdicts

- **Claim: NOT SUPPORTED** (components {'C1': 'NOT EVALUABLE', 'C2a': 'SUPPORTED', 'C2b': 'NOT SUPPORTED', 'C3': 'NOT SUPPORTED'})
- C1: **NOT EVALUABLE** (1 / 1 counted arms of D are design-blind failures; |D| = 1). Wording: design-blind tests are invalid on the R2 (setpoint + dither) design tested.
  - pcorr_native: **FAILURE**; R2 INVALID 1/2 (counted 2), pooled R2 null_raw .188 [.167, .208] INVALID; plac_raw .100 [.033, .187] INCONCLUSIVE; R1 INVALID 0/2 (F_max 0)
- C2a pmrt_nl_eq valid in R1 / R2: **SUPPORTED**
  - cells 4/4, INVALID 0 (F_max 1), VALID 2, INCONCLUSIVE 2; pooled null_raw .038 [.024, .052] VALID; plac_raw .033 [.008, .061] VALID
- C2b eq arms whose native partner is a C1 failure: **NOT SUPPORTED**
  - pcorr_eq (native pcorr_native): **NOT SUPPORTED**
    - cells 4/4, INVALID 0 (F_max 1), VALID 2, INCONCLUSIVE 2; pooled null_raw .038 [.014, .080] INCONCLUSIVE; plac_raw .033 [.008, .067] VALID
- C2b with the R1-failing partners (R-56, sensitivity, no effect): **NOT SUPPORTED** (added: none)
- C2 wording: design-based inference restores validity; adding design covariates does not suffice.

Every eq arm, same rule on R1 + R2, unfiltered (R-56):

| eq arm | C2b membership | native C1 | verdict | INVALID / cells (F_max) | R2 INVALID / planned | pooled R1 truth-null | pooled R2 truth-null |
|---|---|---|---|---|---|---|---|
| pcorr_eq | member | FAILURE | NOT SUPPORTED | 0/4 (1) | 0/2 | 0.028 [0.000, 0.062] | 0.049 [0.007, 0.104] |

- C3 pmrt_nl_eq valid in E4 R3: **NOT SUPPORTED**
  - cells 1/1, INVALID 0 (F_max 0), VALID 0, INCONCLUSIVE 1; pooled plac_raw .083 [.000, .250] INCONCLUSIVE; conf_raw .000 [.000, .000] VALID
  - wording: not supported.
- C3 reported for every eq arm (no claim effect): pcorr_eq SUPPORTED

## V1 validity: INVALID / VALID / counted cells per world-regime (all n)

| world regime | pmrt_nl_eq | pc_native | pcorr_eq | pcorr_native |
|---|---|---|---|---|
| E1 R1 | 0/0/1 | **1**/0/1 | 0/1/1 | 0/0/1 |
| E1 R2 | 0/0/1 | 0/0/1 | 0/0/1 | **1**/0/1 |
| E4 R1 l1 | 0/1/1 | 0/0/1 | 0/1/1 | 0/1/1 |
| E4 R2 l1 | 0/1/1 | 0/0/1 | 0/0/1 | 0/0/1 |
| E4 R3 l1 | 0/0/1 | 0/1/1 | 0/1/1 | 0/1/1 |

(Nx) = planned cells not counted (missing, infeasible, T3-infeasible, untuned or < 10 seeds); nig = not in the arm's grid (pre-registered grid choice, R-54 / R-58: not planned, never missing / PARTIAL).

INVALID cells (2; first 30):
- pc_native|E1|R1|k0.25|n500: null_decl .097 [.062, .132]
- pcorr_native|E1|R2|k0.25|n500: null_raw .188 [.167, .208]; null_decl .118 [.097, .139]

## V2 recall among cells not INVALID (n 500; inv INVALID, inf infeasible, mis missing, unt untuned, few < 10 seeds; NA not applicable, R-42)

| world regime | pmrt_nl_eq | pc_native | pcorr_eq | pcorr_native |
|---|---|---|---|---|
| E1 R1 | 1.00 | inv | 1.00 | 1.00 |
| E1 R2 | 1.00 | 1.00 | 1.00 | inv |
| E4 R1 l1 | .08 | .50 | .67 | .67 |
| E4 R2 l1 | .00 | .33 | .00 | .17 |
| E4 R3 l1 | 1.00 | 1.00 | 1.00 | 1.00 |

## V3 paired recall difference pmrt_nl_eq - arm (neither INVALID, same declaration rule; per-cell 95 % paired-t CI, descriptive)

| arm | rule | block | cells pmrt higher | pmrt lower | CI covers 0 |
|---|---|---|---|---|---|
| pc_native | tau | secondary | 0 | 1 | 3 |
| pcorr_eq | BY | primary | 0 | 1 | 4 |
| pcorr_native | BY | secondary | 0 | 1 | 3 |

## V5 information levels in R2 (pmrt, eq, eq_min, native): recall (* INVALID, ~ INCONCLUSIVE)

| row | pmrt_nl_eq | pcorr_eq | pcorr_native |
|---|---|---|---|
| E1 n500 | 1.00~ | 1.00~ | 1.00* |
| E4 n500 | .00 | .00~ | .17~ |

## V6 E4: placebo_conf rate (raw p, else declared) / wrong-sign rate of the true edge (* INVALID)

| row |  |
|---|

## V7 not testable / not applicable

0 (arm, cell) with counts > 0 (JSON V7).

## V8 secondary KPI -> KPI family

8 (arm, cell) rows (JSON V8).

## V9 kappa sweep (R2, n 1000): recall

| row |  |
|---|

## V10 cost (CPU-s per dataset; mean / max over worlds, regimes; peak RSS MB; infeasible units; T3 = infeasible from DEV cost)

| arm | n 500 | RSS | infeasible |
|---|---|---|---|
| pmrt_nl_eq | 7.7 / 28.8 | 363 | 0 |
| pc_native | 0.1 / 0.4 | 320 | 0 |
| pcorr_eq | 0.0 / 0.1 | 316 | 0 |
| pcorr_native | 0.0 / 0.0 | 316 | 0 |

## V11 integrity

- label PROVISIONAL; failed checks: commits
- freeze commit 93856c230d84abda2ff3b894218dd6cb0ecd47f9; amendments []; records used 480 / expected 480; missing 0; unexpected 0; role mismatch 0; duplicates 0
- commit violations 480; not clean 0; stamp violations 0; candidates incomplete 0; pkgs sets 1
- role:status {'measure:ok': 240, 'tune:ok': 240}; errors 0 (not listed persistent 0); infeasible 0; dataset-hash mismatches 0 (R-41a: equal across all arms of a dataset); ok records without a dataset hash 0 (not-ok 0); multi-platform datasets 0
- BY recheck (p arms): 360 / 360 records agree; tune reproducibility vs DEV: None
